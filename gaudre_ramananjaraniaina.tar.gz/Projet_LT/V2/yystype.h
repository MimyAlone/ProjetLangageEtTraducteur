/* fichier yystype.h*/
typedef union{int valEnt;float valReel;}attribute;
#define YYSTYPE attribute

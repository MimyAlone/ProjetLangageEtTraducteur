/* fichier yystype.h*/
typedef union { char* texte; } attribute ;
#define YYSTYPE attribute
